#include "rb.h"

int main() {
    RBTREE rb;

    // Test 1: Sequential Insertion (1 to 10)
    cout << "--- Test 1: Sequential (1-10) ---" << endl;
    for (int i = 1; i <= 10; i++) {
        rb.insert(i);
    }
    rb.printTree();
    cout << "Total Rotations: " << rb.rotationCount << endl;

    // Test 2: Duplicate Handling
    cout << "\n--- Test 2: Duplicate (Inserting 5 again) ---" << endl;
    rb.insert(5);
    rb.printTree();

    // Test 3: Descending Insertion
    cout << "\n--- Test 3: Descending (30, 20, 10) ---" << endl;
    RBTREE rb2;
    rb2.insert(30);
    rb2.insert(20);
    rb2.insert(10);
    rb2.printTree();

    // Test 4: Random Test
    cout << "\n--- Test 4: Random Test (1-30) ---" << endl;
    RBTREE rb3;
    for (int i = 1; i <= 30; i++) {
        rb3.insert(i);
    }
    rb3.printTree();
    cout << "Final Rotation Count: " << rb3.rotationCount << endl;

    return 0;
}
